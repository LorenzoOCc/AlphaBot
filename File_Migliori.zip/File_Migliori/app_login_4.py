from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import (
    LoginManager, UserMixin,
    login_user, login_required, 
    logout_user, current_user
)
import AlphaBot  # Make sure this module exists
import sqlite3
import time

#per controllo
import os 
print("DB path:", os.path.abspath("login.db"))


app = Flask(__name__)
app.secret_key = "ChiaveSegreta"

login_manager = LoginManager()
login_manager.init_app(app)  # Missing app parameter
login_manager.login_view = "login"

robot = AlphaBot.AlphaBot()
robot.stop()

class User(UserMixin):
    def __init__(self, id, username):
        self.id = id
        self.username = username

def get_db_connection():#controllo
    db_path = "/home/francesco/Alphabot_WEB/login.db"
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_db_connection():
    conn = sqlite3.connect('login.db')#db con username e password
    conn.row_factory = sqlite3.Row
    return conn

@login_manager.user_loader
def load_user(id):
    conn = get_db_connection()
    user_data = conn.execute('SELECT * FROM Credenziali WHERE id = ?', (id,)).fetchone()
    conn.close()
    if user_data:
        return User(user_data['id'], user_data['username'])
    return None

# Verifica credenziali
def verify_user(username, password):
    conn = get_db_connection()
    user_data = conn.execute('SELECT * FROM Credenziali WHERE username = ?', (username,)).fetchone()
    conn.close()
    
    if user_data:
        # Se le password sono in chiaro nel DB (non consigliato in produzione)
        if user_data['password'] == password:
            return User(user_data['id'], user_data['username'])
        # Se le password sono hashate
        # if check_password_hash(user_data['Psw'], password):
        #     return User(user_data['Id'], user_data['User'])
    return None

# User database - usare una password più sicura
# USERS = {
#     "admin": {"password": "alphabot"}
# }

# @login_manager.user_loader
# def load_user(user_id):
#     if user_id in USERS:
#         return User(user_id)
#     return None

# Login
@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("control"))
    
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        print(username, password)
        
        user = verify_user(username, password)

        if user:
            login_user(user)
            flash(f"Benvenuto {username}!", "success")
            return redirect(url_for("control"))
        else:
            flash("Errore nell'inserire e dati: ", "error")
    

        # if username in user and USERS[username]["password"] == password:
        #     user = User(username)
        #     login_user(user)
        #     return redirect(url_for("control"))
        # else:
        #     flash("Invalid username or password", "error")
            
    
    return render_template("login.html")

# Logout
@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

# Control page
@app.route("/control")
@login_required
def control():
    return render_template("control2.html", user=current_user)

# Robot movement - expanded for all directions
@app.route("/move/<cmd>")
@login_required
def move(cmd):
    commands = {
        "W": robot.forward,
        "S": robot.backward,
        "A": robot.left,
        "D": robot.right,
        # "Q": lambda: eseguiDB("Q"),  # Quadrato
        # "T": lambda: eseguiDB("T"),  # Triangolo
        # "E": lambda: eseguiDB("E"),  # Essù
        # "M": lambda: eseguiDB("M"),  # Sommatoria
        
    }
    
    if cmd in commands:
        try:
            commands[cmd]()
            return {"status": "success", "command": cmd}
        except Exception as e:
            return {"status": "error", "message": str(e)}, 500
    else:
        return {"status": "error", "message": "Invalid command"}, 400

# Add a stop endpoint for safety
@app.route("/stop")
@login_required
def stop():
    try:
        robot.stop()
        return {"status": "success", "command": "stop"}
    except Exception as e:
        return {"status": "error", "message": str(e)}, 500

def eseguiDB(scelta):
        if scelta:
            conn = sqlite3.connect("/home/francesco/Alphabot_WEB/AlphaBotDB.db")
            print(conn)
            cursor = conn.cursor()
            cursor.execute("SELECT Descrizione FROM AlphaBot WHERE Tasto = ?", (scelta.upper(),))
            result = cursor.fetchone()
            print(result)
            conn.close()

            if result:
                descrizione = result[0]  # es. "a,1,d,0.37,a,1,d,0.37"
                comandi = descrizione.split(",")
                for comando in comandi:
                    if comando == "a":
                        robot.forward()
                    elif comando == "d":
                        robot.right()
                    elif comando == "s":
                        robot.backward()
                    elif comando == "w":
                        robot.left()
                    elif comando.replace(".", "").isdigit():
                        time.sleep(float(comando))
                    else:
                        robot.stop()
            else:
                print("Comando non trovato nel DB")


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000)